import React, { useState, useEffect } from 'react';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import 'firebase/compat/auth'; // Import firebase/auth to use Firebase Auth
import firebaseConfig from '../firebaseConfig';
import { IonButton, IonContent, IonInput, IonItem, IonLabel, IonList, IonText, IonPage } from '@ionic/react';
import { useHistory } from 'react-router-dom'; // Import useHistory and History from react-router-dom


// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const Home: React.FC = () => {
  const [pins, setPins] = useState<any[]>([]);
  const [newPinTitle, setNewPinTitle] = useState('');
  const [newPinDescription, setNewPinDescription] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchId, setSearchId] = useState<string>('');
  const history = useHistory<History>(); // Assign the correct type to the history object


  useEffect(() => {
    const unsubscribe = firebase.auth().onAuthStateChanged(user => {
      setIsAuthenticated(!!user);
    });
    return () => unsubscribe(); // Cleanup listener on unmount
  }, []);

  const fetchPinsFromFirestore = async () => {
    setLoading(true);
    try {
      if (!isAuthenticated) return;

      const pinsCollection = firebase.firestore().collection('pins');
      const pinsSnapshot = await pinsCollection.get();
      const pinsData = pinsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setPins(pinsData);
    } catch (error) {
      console.error('Error fetching pins: ', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchPinsFromFirestore();
    }
  }, [isAuthenticated]);

  const handleAddPin = async () => {
    if (!isAuthenticated) {
      console.log('User not authenticated. Unable to add pin.');
      return;
    }

    const newPin = {
      title: newPinTitle,
      description: newPinDescription,
      author: firebase.auth().currentUser?.displayName || 'Unknown' // Use current user’s display name
    };

    try {
      const pinsCollection = firebase.firestore().collection('pins');
      const docRef = await pinsCollection.add(newPin);
      setPins(prevPins => [...prevPins, { id: docRef.id, ...newPin }]);
      setNewPinTitle('');
      setNewPinDescription('');
    } catch (error) {
      console.error('Error adding pin: ', error);
    }
  };

  const handleSearch = () => {
    if (searchId.trim()) {
      history.push(`/pin/${searchId}`);
    } else {
      console.log('Please enter a pin ID');
    }
  };

  return (
    <IonPage>
      <IonContent>
        <IonText>
          <h1>Home</h1>
        </IonText>
        {loading ? (
          <IonText>Loading...</IonText>
        ) : isAuthenticated ? (
          <div>
            <IonList>
              {pins.map(pin => (
                <IonItem key={pin.id}>
                  <IonLabel>
                    <strong>{pin.title}</strong>: {pin.description}
                  </IonLabel>
                </IonItem>
              ))}
            </IonList>
            <IonButton expand="full" onClick={fetchPinsFromFirestore}>Refresh Pins</IonButton>
            <div>
              <IonItem>
                <IonLabel position="floating">Pin Title</IonLabel>
                <IonInput
                  value={newPinTitle}
                  onIonChange={e => setNewPinTitle(e.detail.value!)}
                />
              </IonItem>
              <IonItem>
                <IonLabel position="floating">Pin Description</IonLabel>
                <IonInput
                  value={newPinDescription}
                  onIonChange={e => setNewPinDescription(e.detail.value!)}
                />
              </IonItem>
              <IonButton expand="full" onClick={handleAddPin}>Add Pin</IonButton>
            </div>



            <div style={{ marginTop: '200px' }}>
              <IonLabel>Search Pin</IonLabel>
              <IonItem>
                <IonInput
                  value={searchId}
                  onIonChange={e => setSearchId(e.detail.value!)}
                  placeholder="Enter pin ID"
                />
              </IonItem>
              <IonButton expand="full" onClick={handleSearch}>View Pin</IonButton>
            </div>


          </div>
        ) : (
          <IonText>Please log in to view and add pins.</IonText>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Home;
