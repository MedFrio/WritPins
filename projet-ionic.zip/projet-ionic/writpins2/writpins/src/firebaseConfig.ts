import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore'; // Add other Firebase services as needed
import 'firebase/firestore';
import 'firebase/auth';

const firebaseConfig = {
    apiKey: "AIzaSyAM9XW8EHyLz1l0MbMu8OsYOKpAHfw9wvM",
    authDomain: "write-pins-eef4f.firebaseapp.com",
    projectId: "write-pins-eef4f",
    storageBucket: "write-pins-eef4f.appspot.com",
    messagingSenderId: "221679943242",
    appId: "1:221679943242:web:6b38fc06b8a25676c7f0b3"
  };

  firebase.initializeApp(firebaseConfig);

  
  export default firebaseConfig;
  