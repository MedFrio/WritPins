// PinListItem.tsx

import React from 'react';
import { IonItem, IonLabel } from '@ionic/react';
import { Pin, PINS } from '../data/pins'; // Assurez-vous d'importer le type Pin correctement

interface PinListItemProps {
    pin: Pin; // Assurez-vous que Pin est correctement défini dans models/Pin.ts
}

const PinListItem: React.FC<PinListItemProps> = ({ pin }) => {
  return (
    <IonItem>
      <IonLabel>
        <h2>{pin.title}</h2>
        <p>{pin.description}</p>
        <p>Par {pin.author}</p>
      </IonLabel>
    </IonItem>
  );
};

export default PinListItem;
