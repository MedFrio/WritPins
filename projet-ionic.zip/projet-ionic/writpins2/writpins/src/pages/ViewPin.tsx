import React, { useState, useEffect } from 'react';
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonText, IonButton, IonToast } from '@ionic/react';
import { useParams, useHistory } from 'react-router-dom';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import 'firebase/compat/auth';
import firebaseConfig from '../firebaseConfig';

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const ViewPin: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const history = useHistory();
  const [pin, setPin] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [authenticated, setAuthenticated] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<boolean>(false);

  useEffect(() => {
    console.log("Component mounted or ID changed:", id); // Debugging

    const checkAuthStatus = () => {
      const unsubscribe = firebase.auth().onAuthStateChanged(user => {
        if (user) {
          setAuthenticated(true);
          fetchPin();
        } else {
          setAuthenticated(false);
          history.push('/login');
        }
      });
      return unsubscribe;
    };

    const fetchPin = async () => {
      try {
        console.log("Fetching pin with ID:", id); // Debugging
        const docRef = firebase.firestore().collection('pins').doc(id);
        const doc = await docRef.get();
        if (doc.exists) {
          console.log("Pin data:", doc.data()); // Debugging
          setPin(doc.data());
        } else {
          setError('Pin not found');
          setShowToast(true);
        }
      } catch (error) {
        console.error('Error fetching pin:', error);
        setError('Error fetching pin');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    const unsubscribe = checkAuthStatus();
    return () => unsubscribe();
  }, [id, history]);

  if (loading) return <IonContent className="ion-padding"><IonText>Loading...</IonText></IonContent>;

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Pin Details</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        {pin ? (
          <div>
            <h1>{pin.title}</h1>
            <p>{pin.description}</p>
          </div>
        ) : (
          <IonText>No pin found</IonText>
        )}
        {error && (
          <IonToast
            isOpen={showToast}
            onDidDismiss={() => setShowToast(false)}
            message={error}
            color="danger"
            duration={2000}
          />
        )}
      </IonContent>
    </IonPage>
  );
};

export default ViewPin;
