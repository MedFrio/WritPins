// pins.ts
export interface Pin {
    id: number;
    title: string;
    description: string;
    author: string;
}
export const PINS = [
    {
        id: 1,
        title: 'La vie est une aventure audacieuse ou rien du tout.',
        description: 'Helen Keller',
        author: 'Helen Keller'
    },
    {
        id: 2,
        title: 'Le succès, c\'est d\'aller d\'échec en échec sans perdre son enthousiasme.',
        description: 'Winston Churchill',
        author: 'Winston Churchill'
    },
    {
        id: 3,
        title: 'La seule façon de faire du bon travail est d\'aimer ce que vous faites.',
        description: 'Steve Jobs',
        author: 'Steve Jobs'
    },
    {
        id: 4,
        title: 'Le bonheur n\'est pas quelque chose que l\'on trouve au bout du chemin, c\'est la façon de voyager tout au long du chemin.',
        description: 'Inconnu',
        author: 'Inconnu'
    },
    {
        id: 5,
        title: 'La vie est ce qui arrive quand on est occupé à faire d\'autres projets.',
        description: 'John Lennon',
        author: 'John Lennon'
    }
];
