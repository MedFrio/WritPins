import React, { useState } from 'react';
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonInput, IonItem, IonLabel, IonButton, IonToast } from '@ionic/react';
import { useHistory } from 'react-router-dom'; // Import useHistory and History from react-router-dom
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import firebaseConfig from '../firebaseConfig';

// Initialize Firebase with the configuration
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorToast, setErrorToast] = useState<string | null>(null);

  const history = useHistory<History>(); // Assign the correct type to the history object
  
  const handleLogin = async () => {
    try {
      const response = await firebase.auth().signInWithEmailAndPassword(username, password);
      console.log('User logged in:', response.user?.email); // Log successful login
      history.push('/home'); // Use history.push to go to home
    } catch (error) {
      console.error('Authentication failed:', (error as firebase.FirebaseError).code, (error as firebase.FirebaseError).message); // Log authentication error details
      setErrorToast('Identifiant ou mot de passe incorrect.');
    }
  };

  const handleSignUp = async () => {
    try {
      const response = await firebase.auth().createUserWithEmailAndPassword(username, password);
      console.log('User signed up:', response.user?.email); // Log successful sign-up
      history.push('/home'); // Use history.push to go to home
    } catch (error) {
      console.error('Sign-up failed:', (error as firebase.FirebaseError).code, (error as firebase.FirebaseError).message); // Log sign-up error details
      setErrorToast('Erreur lors de la création du compte.');
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Connexion</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonItem>
          <IonLabel position="stacked">Identifiant</IonLabel>
          <IonInput
            value={username}
            onIonChange={(e) => setUsername(e.detail.value!)}
            placeholder="Entrez votre identifiant"
          />
        </IonItem>
        <IonItem>
          <IonLabel position="stacked">Mot de passe</IonLabel>
          <IonInput
            type="password"
            value={password}
            onIonChange={(e) => setPassword(e.detail.value!)}
            placeholder="Entrez votre mot de passe"
          />
        </IonItem>
        <IonButton expand="block" onClick={handleLogin}>
          Se connecter
        </IonButton>
        <IonButton expand="block" color="secondary" onClick={handleSignUp}>
          S'inscrire
        </IonButton>
        <IonToast
          isOpen={!!errorToast}
          message={errorToast || ''}
          duration={3000}
          onDidDismiss={() => setErrorToast(null)}
        />
      </IonContent>
    </IonPage>
  );
};

export default Login;
