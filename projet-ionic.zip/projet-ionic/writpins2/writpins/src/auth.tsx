import React, { createContext, useContext, useState, ReactNode } from 'react';

// Interface defining the shape of authentication state
export interface Auth {
  loggedIn: boolean;
  login: () => void;
  logout: () => void;
}

// Creating the context with initial value of undefined
export const AuthContext = createContext<Auth | undefined>(undefined);

// Custom hook to consume AuthContext
export const useAuth = (): Auth => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// AuthProvider component manages authentication state
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [loggedIn, setLoggedIn] = useState<boolean>(false);

  // Function to simulate login
  const login = () => {
    setLoggedIn(true);
    localStorage.setItem('loggedIn', 'true'); // Store login state in localStorage
  };

  // Function to simulate logout
  const logout = () => {
    setLoggedIn(false);
    localStorage.removeItem('loggedIn'); // Remove login state from localStorage
  };

  // Providing AuthContext with value
  const authContextValue: Auth = { loggedIn, login, logout };

  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};
